﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
public partial class payment : System.Web.UI.Page
{
    Class1 cs = new Class1();
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        if (Request.QueryString.Count > 0)
        {
            int donid = Convert.ToInt32(Request.QueryString["cid"].ToString());

            int a = cs.insert("insert into payment(cardnumber,expdate,cvv,amount,donid,nameoncard,cid,status)values('" + txtcardnumber.Text + "','" + txtexp.Text + "','" + txtcvv.Text + "','" + txtamount.Text + "','" + Session["don"] + "','" + txtnameoncard.Text + "','"+donid +"','pending')");
            if (a > 0)
            {
                Response.Redirect("Home.aspx");
            }
        }
    }
}