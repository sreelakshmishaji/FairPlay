﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

public partial class homeMasterPage : System.Web.UI.MasterPage
{
    Class1 cs = new Class1();
    string role1;
    protected void Page_Load(object sender, EventArgs e)
    {
        if(!IsPostBack)
        {
            
        }
    }

   

  

   

    protected void Button4_Click(object sender, EventArgs e)
    {

    }

    protected void Button4_Click1(object sender, EventArgs e)
    {

    }

    protected void Button5_Click(object sender, EventArgs e)
    {

    }

    protected void LinkButton1_Click(object sender, EventArgs e)
    {
        


            int a = cs.insert("insert into volreg(vname,district,city,email,phonenumber,username,password,status,availability,donid)values('" + txtname.Text + "','" + txtdist.Text + "','" + txtcity.Text + "','" + txtemail.Text + "','" + txtphone.Text + "','" + txtuser.Text + "','" + txtpass.Text + "','pending','yes','0')");
            int b = cs.insert("insert into log(username,password,role)values('" + txtuser.Text + "','" + txtpass.Text + "','1')");
            if (a > 0 && b > 0)
            {
                txtname.Text = "";
                txtdist.Text = "";
                txtcity.Text = "";
                
                txtemail.Text = "";
                txtphone.Text = "";
                txtuser.Text = "";
                txtpass.Text = "";
                txtcpass.Text = "";
            
        }
    }
    protected void LinkButton2_Click(object sender, EventArgs e)
    {
        int v = cs.insert("insert into campreg(campname,district,campplace,individuals,username,password,phone,status,did)values('" + txtcampname.Text + "','" + txtcampdist.Text + "','" + txtcampplace.Text + "','" + txtcampmembr.Text + "','" + txtcampuser.Text + "','" + txtcamppass.Text + "','"+txtcampphone.Text+"','pending','0')");
        int b = cs.insert("insert into log(username,password,role)values('" + txtcampuser.Text + "','" + txtcamppass.Text + "','2')");
        if (v > 0 && b > 0)
        {
            txtcampname.Text = "";
            txtcampdist.Text = "";
          
            txtcampplace.Text = "";
            txtcampmembr.Text = "";
            txtcampuser.Text = "";
            txtcamppass.Text = "";
            txtcampcpass.Text = "";
            txtcampphone.Text = "";
        }
    }

   

   

    protected void LinkButton5_Click(object sender, EventArgs e)
    {
        int f = cs.insert("insert into donation( name,district,city,email,phone,status,vid)values('" + txtdonorname.Text + "','" + txtdonordist.Text + "','" + txtdonorcity.Text + "','" + txtdonoremail.Text + "','" + txtdonorphone.Text + "','pending','0') ");
        if(f>0)
        {
            txtdonorname.Text = "";
            txtdonordist.Text = "";
            txtdonorcity.Text = "";
            txtdonoremail.Text = "";
            txtdonorphone.Text = "";
            DataTable dt = cs.select("select top 1 * from donation  order by donid  Desc");
            if(dt.Rows.Count>0)
            {
                string donid = dt.Rows[0]["donid"].ToString();
                Response.Redirect("Donate1.aspx?id=" + donid.ToString());
            }
          
        }
       
    }

    protected void LinkButton3_Click1(object sender, EventArgs e)
    {
        DataTable dt = cs.select("select * from log where username='" + Txtloguser.Text + "' and password='" + Txtlogpass.Text + "'");
        if (dt.Rows.Count > 0)
        {

            role1 = dt.Rows[0]["role"].ToString();

            if (role1 == "1")
            {
                DataTable dm = cs.select("select * from volreg where username='" + Txtloguser.Text + "' and status='Approved'");
                if (dm.Rows.Count > 0)
                {
                    Session["vid"] = dm.Rows[0]["vid"].ToString();
                    Response.Redirect("~/volunteer/volunteer.aspx");
                }
                else
                {
                    Response.Write("Invalid User");
                }
            }
            if (role1 == "2")
            {
                DataTable dc = cs.select("select * from campreg where username='" + Txtloguser.Text + "' and status='Approved'");
                if (dc.Rows.Count > 0)
                {
                    Session["cid"] = dc.Rows[0]["cid"].ToString();
                    Response.Redirect("~/camp/camp.aspx");
                }
            }
            if (role1 == "3")
            {
                Response.Redirect("~/admin/admin1.aspx");
            }
            if(role1 == "4")
            {
                DataTable dc = cs.select("select * from userreg where username='" + Txtloguser.Text + "' and status='Approved'");
                if (dc.Rows.Count > 0)
                {
                    Session["cid"] = dc.Rows[0]["uid"].ToString();
                    Response.Redirect("~/user/user.aspx");
                }

            }
            if (role1 == "4")
            {
                DataTable dc = cs.select("select * from orphreg where username='" + Txtloguser.Text + "' and status='Approved'");
                if (dc.Rows.Count > 0)
                {
                    Session["oid"] = dc.Rows[0]["oid"].ToString();
                    Response.Redirect("~/orphanage/orphanage.aspx");
                }

            }
        }
        else
        {
            Response.Write("invalid user");
        }
    }

  

   

    protected void LinkButton6_Click1(object sender, EventArgs e)
    {
       
    }

  

    protected void lnk_Click(object sender, EventArgs e)
    {
        int f = cs.insert("insert into paydonor( name,email,phone,status)values('" + pname.Text + "','" + pmail.Text + "','" + pphone.Text + "','pending',) ");
        if (f > 0)
        {
            DataTable dt = cs.select("SELECT * FROM    paydonor WHERE   pdid = (SELECT MAX(pdid)  FROM paydonor)");
            string did = dt.Rows[0]["pdid"].ToString();
            Response.Redirect("payment.aspx?donid=" + did.ToString());
        } }

    protected void LinkButton6_Click(object sender, EventArgs e)
    {

    }

    protected void LinkButton6_Click2(object sender, EventArgs e)
    {
        int a = cs.insert("insert into userreg(name,address,email,phone,username,password,status)values('" + txtuuname.Text + "','" + txtuaddress.Text + "','" + txtuemail.Text + "','" + txtuphone.Text + "','" + txtuusername.Text + "','" + txtupassword.Text + "','pending')");
        int b = cs.insert("insert into log(username,password,role)values('" + txtuusername.Text + "','" + txtupassword.Text + "','4')");
        if (a > 0 && b > 0)
        {
            txtuuname.Text = "";
            txtuaddress.Text = "";
            txtuemail.Text = "";
            txtuphone.Text = "";
            txtuusername.Text = "";
            txtupassword.Text = "";

        }
    }

    protected void LinkButton8_Click(object sender, EventArgs e)
    {
        int a = cs.insert("insert into orphreg(name,address,email,phone,username,password,status)values('" + txtoname.Text + "','" + txtoaddress.Text + "','" + txtoemail.Text + "','" + txtophone.Text + "','" + txtouname.Text + "','" + txtopass.Text + "','pending')");
        int b = cs.insert("insert into log(username,password,role)values('" + txtouname.Text + "','" + txtopass.Text + "','5')");
        if (a > 0 && b > 0)
        {
            txtoname.Text = "";
            txtoaddress.Text = "";
            txtoemail.Text = "";
            txtophone.Text = "";
            txtouname.Text = "";
            txtopass.Text = "";

        }
    }
}

