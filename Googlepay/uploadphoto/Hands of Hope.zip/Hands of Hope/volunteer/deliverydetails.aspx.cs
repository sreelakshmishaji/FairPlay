﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
public partial class volunteer_deliverydetails : System.Web.UI.Page
{
    Class1 cs = new Class1();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            Label13.Visible = false;
            GridView2.Visible = false;
            int vid = Convert.ToInt32(Session["vid"].ToString());
            DataTable dt = cs.select("select * from deliveryrequest p join donation j on p.donid=j.donid  where p.vid='"+vid+"' and p.status='reached' ");
            GridView1.DataSource = dt;
            GridView1.DataBind();
        }
    }

  
    protected void GridView1_RowCommand1(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandName == "view")
        {
            int did = Convert.ToInt32(e.CommandArgument.ToString());
            Session["did"] = did.ToString();
            Label13.Visible = true;
            GridView2.Visible = true;
            DataTable dt = cs.select("select * from campreg where did='0' ");
            GridView2.DataSource = dt;
            GridView2.DataBind();
        }
    }

    protected void GridView2_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        int cid = Convert.ToInt32(e.CommandArgument.ToString());
        int did = Convert.ToInt32(Session["did"].ToString());

        DataTable dt = cs.select("select * from deliveryrequest where did='" + did + "'");
        if (dt.Rows.Count > 0)
        {
            int vid = Convert.ToInt32(dt.Rows[0]["vid"].ToString());
            int food= Convert.ToInt32(dt.Rows[0]["dfood"].ToString());
            int b = cs.insert("insert into camprequest(campid,vid,did,food,status)values('" + cid + "','" + vid + "','" + did + "','" + food + "','pending') ");
    
            int c = cs.insert("update campreg set did='" + did + "' where cid='" + cid + "'");
            Response.Redirect("deliverydetails.aspx");
        } }
}