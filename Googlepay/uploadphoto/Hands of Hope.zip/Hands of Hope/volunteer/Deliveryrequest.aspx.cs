﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

public partial class volunteer_Deliveryrequest : System.Web.UI.Page
{
    Class1 cs = new Class1();
    protected void Page_Load(object sender, EventArgs e)
    {
        if(!IsPostBack)
        {
            DataTable dt = cs.select("select * from deliveryrequest p join donation j on p.donid=j.donid  where p.vid='"+Session["vid"]+"' and p.status='pending' ");
            GridView1.DataSource = dt;
            GridView1.DataBind();
        }
    }

    protected void GridView1_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandName == "view")
        {
            int a = cs.insert("update deliveryrequest set status='reached'  where did='" + e.CommandArgument + "' ");
            DataTable dp = cs.select("select * from deliveryrequest where did='" + e.CommandArgument + "'");
            if (dp.Rows.Count > 0)
            {
                int donid = Convert.ToInt32(dp.Rows[0]["donid"].ToString());

                //string fg = dp.Rows[0]["donorname"].ToString();
                int c = cs.insert("update donation set status='success' where donid='" + donid + "'");
                Response.Redirect("~/volunteer/Deliveryrequest.aspx");
            }
        }
        if(e.CommandName=="rejected")
        {
            int a = cs.insert("update deliveryrequest set status='rejected',vid='0'  where did='" + e.CommandArgument + "' ");
            DataTable dk = cs.select("select * from deliveryrequest where did='"+e.CommandArgument+"'");
            if (dk.Rows.Count > 0)
            {
                //string dn = dk.Rows[0]["donorname"].ToString();
                int b = cs.insert("update donation set status='rejected',vid='0'  where donid='" + e.CommandArgument + "'");
                Response.Redirect("~/volunteer/Deliveryrequest.aspx");
            }
        }
    }
}