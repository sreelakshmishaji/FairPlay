﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Net.Mail;

public partial class admin_Donationmessage : System.Web.UI.Page
{
    Class1 cs = new Class1();
    protected void Page_Load(object sender, EventArgs e)
    {
        if(!IsPostBack)
        {
            GridView2.Visible = false;
            DataTable dt = cs.select("select * from donation d join food f on d.donid=f.dnid where f.status='pending'");
            GridView1.DataSource = dt;
            GridView1.DataBind();
        }

    }

    protected void GridView1_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandName == "view")
        {
            //Response.Redirect("newpage1.aspx?pid=" + e.CommandArgument);
            //int a = cs.insert("update campreg set status='Approved' where id='" + e.CommandArgument + "'");
            //int a = cs.insert("update donation set status='approved' where donid='"+e.CommandArgument+"' ");
            Response.Redirect("possibleaccepters.aspx?id=" + e.CommandArgument);
        }
    }

   

    protected void Button1_Click1(object sender, EventArgs e)
    {
        GridView2.Visible = true;
        DataTable dm = cs.select("select a.pdid, a.name,p.amount,a.email,a.phone from payment p join paydonor a on p.donid=a.pdid");
        GridView2.DataSource = dm;
        GridView2.DataBind();
    }

    protected void GridView2_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if(e.CommandName=="view")
        {
            int donid =Convert.ToInt32( e.CommandArgument.ToString());
            DataTable dt = cs.select("select * from donation where donid='" + donid + "'");
            string email = dt.Rows[0]["email"].ToString();

            SmtpClient smtp = new SmtpClient();
            smtp.Host = "smtp.gmail.com";
            smtp.Port = 587;
            smtp.Credentials = new System.Net.NetworkCredential("mysoft.123@gmail.com", "mysoft123");
            smtp.EnableSsl = true;
            MailMessage msg = new MailMessage();
            msg.Subject = "Payment recieved";
            msg.Body = "Hearfull condolences ";
            string toaddress = email;
            msg.To.Add(toaddress);
            string fromaddress = "mysoft.123@gmail.com";
            msg.From = new MailAddress(fromaddress);
            try
            {
                smtp.Send(msg);
            }
            catch
            {
                throw;
            }
            ScriptManager.RegisterStartupScript(this, GetType(), "Popup", "successalert();", true);


        }
    }
}