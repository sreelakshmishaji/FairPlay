﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
public partial class admin_balance : System.Web.UI.Page
{
    Class1 cs = new Class1();
    int needed;
    int excess;
    protected void Page_Load(object sender, EventArgs e)
    {
        if(!IsPostBack)
        {
            details.Visible = false;
            DataTable dt = cs.select("select p.bid, a.campname,a.phone,p.supply,p.people,p.balance from balance p join campreg a on p.cid=a.cid where p.status='extra'");
            GridView1.DataSource = dt;
            GridView1.DataBind();
        }
    }

    protected void GridView1_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if(e.CommandName=="view")
        {
            details.Visible = true;
            Session["bid"] = e.CommandArgument;
            //DataTable dj = cs.select("select * from balance where bid='" + e.CommandArgument + "'");
            DataTable dm = cs.select(" select p.bid,p.needed,a.campname,a.cid from balance p join campreg a on p.cid=a.cid where p.status='needs'");
            if(dm.Rows.Count>0)
            {
                DropDownList1.DataSource = dm;
                DropDownList1.DataTextField = "campname";
                DropDownList1.DataValueField = "bid";
                DropDownList1.DataBind();
                DropDownList1.Items.Insert(0, "select");
            }
        }
    }

    protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
    {
        DataTable dn = cs.select("select * from balance where bid='" + DropDownList1.SelectedItem.Value + "' ");
        if(dn.Rows.Count>0)
        {
             needed =Convert.ToInt32( dn.Rows[0]["needed"].ToString());
            txtneeded.Text =Convert.ToString( needed.ToString());
            DataTable dj = cs.select("select * from balance where bid='" + Session["bid"] + "'");
            if(dj.Rows.Count>0)
            {
                 excess = Convert.ToInt32(dj.Rows[0]["balance"].ToString());
                txtexcess.Text= excess.ToString();

                if(needed>excess)
                {
                    int balance = needed - excess;
                    txtbalance.Text = balance.ToString();
                    
                }
                else if(excess>needed)
                {
                    int balance = excess - needed;
                    txtbalance.Text = balance.ToString();
                }
                else if(needed==excess)
                {
                    int balance = needed - excess;
                    txtbalance.Text = balance.ToString();
                }
            }
        }
    }

    protected void btsearch_Click(object sender, EventArgs e)
    {
        int need =Convert.ToInt32( txtneeded.Text);
        int exc= Convert.ToInt32(txtexcess.Text);
        if (need > exc)
        {
            //int balance = needed - excess;
            //txtbalance.Text = balance.ToString();
            int a = cs.insert("update balance set balance='0' , status='full' where bid='" + Session["bid"] + "'");
            int b = cs.insert("update balance set needed='" + txtbalance.Text + "' where bid='" + DropDownList1.SelectedItem.Value + "'");
            Response.Redirect("balance.aspx");

        }
        else if (exc > need)
        {
            //int balance = excess - needed;
            //txtbalance.Text = balance.ToString();
            int a = cs.insert("update balance set balance='"+txtbalance.Text+"'  where bid='" + Session["bid"] + "'");
            int b = cs.insert("update balance set needed='0', status='full' where bid='" + DropDownList1.SelectedItem.Value + "'");
            Response.Redirect("balance.aspx");
        }
        else if (need == exc)
        {
            //int balance = needed - excess;
            //txtbalance.Text = balance.ToString();
            int a = cs.insert("update balance set balance='0' , status='full' where bid='" + Session["bid"] + "'");
            int b = cs.insert("update balance set needed='0', status='full' where bid='" + DropDownList1.SelectedItem.Value + "'");
            Response.Redirect("balance.aspx");
        }
    }
}