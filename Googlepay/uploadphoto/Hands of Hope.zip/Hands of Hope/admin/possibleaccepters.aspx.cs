﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

public partial class admin_possibleaccepters : System.Web.UI.Page
{
    Class1 cs = new Class1();
    string drop;
    string food;
    string amount;
    string data;
    string district, city, phone,dname;
    protected void Page_Load(object sender, EventArgs e)
    {
        if(!IsPostBack)
        {
            Label1.Visible = false;
            if (Request.QueryString.Count > 0)
            {


                int kid = Convert.ToInt32(Request.QueryString["id"].ToString());
                DataTable dm = cs.select("select * from food where dnid='" + kid + "'");

                GridView1.DataSource = dm;
                GridView1.DataBind();

            }
            else
            {
                DataTable dm = cs.select("select * from food ");

                GridView1.DataSource = dm;
                GridView1.DataBind();
            }
           
        }
        

    }

    protected void GridView1_RowCommand(object sender, GridViewCommandEventArgs e)
    {
       if(e.CommandName== "view")
        {
            //DropDownList df = (e.rowFindControl("DropDownList1") as DropDownList);
            //int rowindex = int.Parse(e.CommandArgument.ToString().Trim());
            //DropDownList dropdown = (DropDownList)GridView1.Rows[rowindex].FindControl("DropDownList1");

            string pid = Request.QueryString["id"].ToString();
            DataTable dj = cs.select("select * from donation d join food f on d.donid=f.dnid where f.dnid='" + pid + "'");
            food = dj.Rows[0]["food"].ToString();
            //amount = dj.Rows[0]["amount"].ToString();
            district = dj.Rows[0]["district"].ToString();
            city = dj.Rows[0]["city"].ToString();
          int  donid =Convert.ToInt32( dj.Rows[0]["donid"].ToString());
            phone = dj.Rows[0]["phone"].ToString();
            int u = cs.insert("update donation set status='approved',vid='"+ Session["drop"]+"' where donid='" + pid + "' ");
            int a = cs.insert("insert into deliveryrequest(donid,vid,dphone,ddistrict,dcity,dfood,status)values('" + donid + "','" + Session["drop"] + "','"+phone+"','"+district+"','"+city+"','" + food + "','pending')");
            int b = cs.insert("update  volreg set availability='no' ,donid='"+pid+"' where vid='" + Session["drop"] + "'");
            //Response.Redirect("possibleaccepters.aspx");
            if(a>0 && b>0)
            {
                ScriptManager.RegisterStartupScript(this, GetType(), "Popup", "successalert();", true);
            }
        }
       
        
    }

    protected void GridView1_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            DropDownList df = (e.Row.FindControl("DropDownList1") as DropDownList);

            DataTable dt = cs.select("select * from volreg where availability='yes' and donid='0'");
            df.DataSource = dt;
            df.DataValueField = "vid";
            df.DataTextField = "vname";
            df.DataBind();
            df.Items.Insert(0, "select");

            //Session["drop"] = df.SelectedItem.Value.ToString();

        }
    }



    protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
    {
        DropDownList dd = (DropDownList)sender;
         data = dd.SelectedItem.Value;
        Session["drop"] =Convert.ToInt32( data.ToString());
    }
}