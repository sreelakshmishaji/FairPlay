﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
public partial class admin_Donationmsg : System.Web.UI.Page
{
    Class1 cs = new Class1();
    protected void Page_Load(object sender, EventArgs e)
    {
        if(!IsPostBack)
        {
            GridView4.Visible = false;
            lbldetails.Visible = false;
            GridView2.Visible = false;
            //GridView2.Visible = false;
            DataTable dt = cs.select("select * from donation ");
            GridView1.DataSource = dt;
            GridView1.DataBind();
        }
    }

    protected void GridView1_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandName == "details")
        {
            DataList1.Visible = false;
            lbldetails.Visible = true;
            GridView2.Visible = true;
            GridView4.Visible = false;
            GridView3.Visible = false;
            DataTable dt = cs.select("select * from donation where donid='" + e.CommandArgument + "' ");
            GridView2.DataSource = dt;
            GridView2.DataBind();
        }
        if (e.CommandName == "cloth")
        {
            DataList1.Visible = false;
            lbldetails.Visible = false;
            GridView2.Visible = false;
            GridView4.Visible = false;
            GridView3.Visible = true;
            DataTable dt = cs.select("select * from doncloth d  join campreg c on d.cid=c.cid where d.dnid='" + e.CommandArgument + "'");
            if(dt.Rows.Count>0)
            {
                GridView3.Visible = true;
                GridView3.DataSource = dt;
                GridView3.DataBind();

            }
            else
            {
                ScriptManager.RegisterStartupScript(this, GetType(), "Popup", "alert();", true);
            }
        }
        if (e.CommandName == "med")
        {
            DataTable dt = cs.select("select * from donmedicine d  join campreg c on d.cid = c.cid where d.dnid ='" + e.CommandArgument + "'");
            if(dt.Rows.Count>0)
            {
                DataList1.Visible = true;
                lbldetails.Visible = false;
                GridView2.Visible = false;
                GridView3.Visible = false;
                GridView4.Visible = false;
                DataList1.DataSource = dt;
                DataList1.DataBind();
            }
            else
            {
                ScriptManager.RegisterStartupScript(this, GetType(), "Popup", "alert();", true);
            }
        }
        if (e.CommandName == "Don")
        {
            DataList1.Visible = false;
            lbldetails.Visible = false;
            GridView2.Visible = false;
            GridView3.Visible = false;
            GridView4.Visible = true;
            DataTable dt = cs.select("select * from payment p join campreg c on p.cid=c.cid where p.donid='" + e.CommandArgument + "'");
            if(dt.Rows.Count>0)
            {
                GridView4.Visible = true;
                GridView4.DataSource = dt;
                GridView4.DataBind();
            }
            else
            {
                ScriptManager.RegisterStartupScript(this, GetType(), "Popup", "alert();", true);
            }

        }
        if (e.CommandName == "food")
        {
            DataTable dt = cs.select("select * from food where dnid='" + e.CommandArgument + "' ");
            if(dt.Rows.Count>0)
            {
                Response.Redirect("possibleaccepters.aspx?id=" + e.CommandArgument);
            }
            else
            {
                ScriptManager.RegisterStartupScript(this, GetType(), "Popup", "alert();", true);
            }
            
        }


    }

    protected void GridView3_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if(e.CommandName== "Dress")
        {
            int a = cs.insert("update doncloth set status='Accepted' where dnid='"+e.CommandArgument+"'");
            if(a>0)
            {
                ScriptManager.RegisterStartupScript(this, GetType(), "Popup", "successalert();", true);
            }
        }
    }

    protected void GridView4_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandName == "amount")
        {
            int a = cs.insert("update payment set status='Accepted' where pid='" + e.CommandArgument + "'");
            if (a > 0)
            {
                ScriptManager.RegisterStartupScript(this, GetType(), "Popup", "successalert();", true);
            }
        }
    }
}