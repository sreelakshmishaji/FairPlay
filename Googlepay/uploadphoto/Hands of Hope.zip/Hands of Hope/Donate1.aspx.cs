﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
public partial class Donate1 : System.Web.UI.Page
{
    Class1 cs = new Class1();
    protected void Page_Load(object sender, EventArgs e)
    {
        if(!IsPostBack)
        {
          medic.Visible = false;
            name.Visible = false;
            DataTable dt = cs.select("select * from campreg");
            GridView1.DataSource = dt;
            GridView1.DataBind();
            lbldetails.Visible = false;
            DataList1.Visible = false;
            food.Visible = false;
           
        }
    }

    protected void GridView1_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandName == "details")
        {
            medic.Visible = false;
            GridView2.Visible = true;
            DataTable dt = cs.select("select * from campreg where cid='" + e.CommandArgument + "' ");
            GridView2.DataSource = dt;
            GridView2.DataBind();
            lbldetails.Visible = true;
            lbldetails.Text = "Details";
            DataList1.Visible = false;
            name.Visible = false;
            food.Visible = false;
           
        }
        if (e.CommandName == "cloth")
        {
            medic.Visible = false;
            DataList1.Visible = true;
            DataTable dt = cs.select("select a.clid,a.cid,a.mens,a.womens,a.kids,a.members from cloth a join campreg c on a.cid=c.cid  where a.cid='" + e.CommandArgument + "' ");
            DataList1.DataSource = dt;
            DataList1.DataBind();
            Session["cl"] = dt.Rows[0]["cid"].ToString();
            name.Visible = true;
            GridView2.Visible = false;
            lbldetails.Visible = false;
            food.Visible = false;

           

        }
        if (e.CommandName == "food")
        {
            medic.Visible = false;
            food.Visible = true;
            DataList1.Visible = false;
            name.Visible = false;
            GridView2.Visible = false;
            lbldetails.Visible = false;
            DataTable dt = cs.select("select * from campreg where cid='"+e.CommandArgument+"' ");
            txtmembers.Text = dt.Rows[0]["individuals"].ToString();
            Session["cd"] = e.CommandArgument.ToString();
            

        }
        if (e.CommandName == "med")
        {
            food.Visible = false;
            DataList1.Visible = false;
            name.Visible = false;
            GridView2.Visible = false;
            lbldetails.Visible = false;
            medic.Visible = true;
            DataTable dt = cs.select("select * from medicine where cid='" + e.CommandArgument + "' ");
           if(dt.Rows.Count>0)
            {
                DropDownList1.DataSource = dt;
                DropDownList1.DataTextField = "medicine";
                DropDownList1.DataValueField = "mid";
                DropDownList1.DataBind();
                DropDownList1.Items.Insert(0, "select");
                Session["cv"] = e.CommandArgument.ToString();
            }
            //DataList2.DataSource = dt;
            //DataList2.DataBind();
           

        }
        if (e.CommandName == "Don")
        {

            if (Request.QueryString.Count > 0)
            {
                string dnid = Request.QueryString["id"].ToString();
                string cid = e.CommandArgument.ToString();
                Session["don"] = dnid.ToString();
                Response.Redirect("payment.aspx?cid="+cid.ToString());
            }



            }


        }

    protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
    {
        
        DataTable dt = cs.select("select * from medicine where mid='" + DropDownList1.SelectedValue + "'");
        txtmedquantity.Text = dt.Rows[0]["quantity"].ToString();
        medic.Visible = true;
    }

   

    protected void LinkButton4_Click(object sender, EventArgs e)
    {
        if (Request.QueryString.Count > 0)
        {
            string dnid = Request.QueryString["id"].ToString();
            int a = cs.insert("insert into doncloth(cid,dnid,men,women,kid,status)values('" + Session["cl"] + "','" + dnid + "','" + TextBox7.Text + "','" + TextBox8.Text + "','" + TextBox9.Text + "','pending')");
            if (a > 0)
            {
                TextBox7.Text = "";
                TextBox8.Text = "";
                TextBox9.Text = "";
                ScriptManager.RegisterStartupScript(this, GetType(), "Popup", "successalert();", true);
            }

        }

    }

    protected void LinkButton5_Click(object sender, EventArgs e)
    {
        if (Request.QueryString.Count > 0)
        {
            string dnid = Request.QueryString["id"].ToString();
            int a = cs.insert("insert into food(dnid,cid,food,status)values('" + dnid + "','" + Session["cd"] + "','" + txtmedproviding.Text + "','pending')");
            if (a > 0)
            {
                txtmedproviding.Text = "";
                txtmembers.Text = "";
               
                ScriptManager.RegisterStartupScript(this, GetType(), "Popup", "successalert();", true);
            }

        }
    }

    protected void LinkButton7_Click(object sender, EventArgs e)
    {
        if (Request.QueryString.Count > 0)
        {
            string dnid = Request.QueryString["id"].ToString();
            int a = cs.insert("insert into donmedicine(cid,dnid,medicine,quantity,providing,status)values('" + Session["cv"] + "','" + dnid + "','" + DropDownList1.SelectedItem.Text + "','"+txtmedquantity.Text+"','"+txtproviding.Text+"','pending')");
            if (a > 0)
            {
                txtmedquantity.Text = "";
                txtproviding.Text = "";

                ScriptManager.RegisterStartupScript(this, GetType(), "Popup", "successalert();", true);
            }

        }
    }
}