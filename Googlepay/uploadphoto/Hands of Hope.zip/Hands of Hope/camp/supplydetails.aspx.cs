﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
public partial class camp_supplydetails : System.Web.UI.Page
{
    Class1 cs = new Class1();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            int cid = Convert.ToInt32(Session["cid"].ToString());
            DataTable dt = cs.select("select v.vid,  v.vname,c.name,e.supply,e.people,e.balance,e.needed from camprequest j join balance e on j.rid=e.rid   join deliveryrequest d on j.did=d.did join donation c on d.donid=c.donid join volreg v on j.vid=v.vid where e.cid='" + cid + "'");
            if (dt.Rows.Count > 0)
            {
                //int vid = Convert.ToInt32(dt.Rows[0]["vid"].ToString());
                //int a = cs.insert("update volreg set availability='completed' where vid='" + vid + "'");


                GridView1.DataSource = dt;
                GridView1.DataBind();
            }
        }
    }

    protected void GridView1_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandName == "view")
        {
            int a = cs.insert("update volreg set availability='completed' where vid='"+e.CommandArgument+"'");
            if (a > 0)
            {
                ScriptManager.RegisterStartupScript(this, GetType(), "Popup", "successalert();", true);
            }
        }
    }
}