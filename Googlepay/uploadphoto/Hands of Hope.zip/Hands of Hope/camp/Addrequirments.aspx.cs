﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
public partial class camp_Addrequirments : System.Web.UI.Page
{
    Class1 cs = new Class1();
    protected void Page_Load(object sender, EventArgs e)
    {
        if(!IsPostBack)
        {
            details.Visible = false;
            med.Visible = false;
            med2.Visible = false;
        }
    }

    protected void LinkButton1_Click(object sender, EventArgs e)
    {
        details.Visible = true;
        med.Visible = false;
        med2.Visible = false;
        string cid = Session["cid"].ToString();
        DataTable dt = cs.select("select * from campreg where cid='" + cid + "'");
        if(dt.Rows.Count>0)
        {
            Label1.Text = dt.Rows[0]["individuals"].ToString();
        }
    }

    protected void LinkButton2_Click(object sender, EventArgs e)
    {
        med2.Visible = false;
        med.Visible = true;
        details.Visible = false;
        DataTable dt = cs.select("select * from med");
        if (dt.Rows.Count > 0)
        {
            DropDownList1.DataSource = dt;
            DropDownList1.DataTextField = "medicine";
            DropDownList1.DataValueField = "mdid";
            DropDownList1.DataBind();
            DropDownList1.Items.Insert(0, "select");
        }

    }

    protected void LinkButton3_Click(object sender, EventArgs e)
    {
        med2.Visible = true;
        med.Visible = false;
    }

    protected void Button2_Click(object sender, EventArgs e)
    {
        int a = cs.insert("insert into med(medicine)values('" + txtmed.Text + "')");
        if(a>0)
        {
            Response.Redirect("Addrequirments.aspx");
        }
    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        string cid = Session["cid"].ToString();
        int a = cs.insert("insert into medicine(cid,medicine,quantity)values('" + cid + "','" + DropDownList1.SelectedItem.Text + "','" + txtquantity.Text + "')");
        if(a>0)
        {
            ScriptManager.RegisterStartupScript(this, GetType(), "Popup", "successalert();", true);
        }
    }

    protected void btsearch_Click(object sender, EventArgs e)
    {
        string cid = Session["cid"].ToString();
        int a = cs.insert("insert into cloth(cid,members,mens,womens,kids)values('" + cid + "','" + Label1.Text + "','" + txtmen.Text + "','" + txtwomen.Text + "','" + txtkids.Text + "')");
        if (a > 0)
        {
            ScriptManager.RegisterStartupScript(this, GetType(), "Popup", "successalert();", true);
        }
    }
}