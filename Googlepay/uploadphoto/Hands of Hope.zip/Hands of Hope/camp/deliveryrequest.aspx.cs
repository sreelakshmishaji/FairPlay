﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
public partial class camp_deliveryrequest : System.Web.UI.Page
{
    Class1 cs = new Class1();
    protected void Page_Load(object sender, EventArgs e)
    {
        if(!IsPostBack)
        {
            details.Visible = false;
            int cid = Convert.ToInt32(Session["cid"].ToString());
            DataTable dt = cs.select("select j.rid, a.vname,p.dfood,d.name,c.individuals from camprequest j join volreg a on j.vid=a.vid join deliveryrequest p on j.did=p.did join donation d on p.donid=d.donid join campreg c on j.campid=c.cid where j.campid='" + cid + "' and j.status='pending'");
            GridView1.DataSource = dt;
            GridView1.DataBind();
        }
    }

    protected void GridView1_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if(e.CommandName=="view")
        {
            details.Visible = true;
            DataTable dt = cs.select("select * from camprequest where rid='" + e.CommandArgument + "'");
            if (dt.Rows.Count>0)
            {
                int food =Convert.ToInt32( dt.Rows[0]["food"].ToString());
                txtfood.Text = food.ToString();
                int cid= Convert.ToInt32(dt.Rows[0]["campid"].ToString());
                DataTable dm = cs.select("select * from campreg where cid='" + cid + "'");
                if(dm.Rows.Count>0)
                {
                    int individuals= Convert.ToInt32(dm.Rows[0]["individuals"].ToString());
                    txtindividuals.Text = individuals.ToString();
                    if (food>individuals)
                    {
                        int balance = food - individuals;
                        txtbalance.Text = balance.ToString();
                        //Session["balance"] = balance.ToString();
                        int a = cs.insert("insert into balance(rid,cid,supply,people,balance,needed,status)values('" + e.CommandArgument + "','" + cid + "','" + txtfood.Text + "','" + txtindividuals.Text + "','" + balance + "','0','extra')");
                        //txtbalance.Text = balance.ToString();
                        //txtfood.Text = "";
                        //txtindividuals.Text = "";
                        int b = cs.insert("update camprequest set status='selected' where rid='" + e.CommandArgument + "' ");


                    }
                    else if(individuals>food)
                    {
                        int needed = individuals - food;
                        txtbalance.Text = needed.ToString();
                        //Session["balance"] = balance.ToString();
                        int a = cs.insert("insert into balance(rid,cid,supply,people,balance,needed,status)values('" + e.CommandArgument + "','" + cid + "','" + txtfood.Text + "','" + txtindividuals.Text + "','0','"+needed+"','needs')");
                        //txtbalance.Text = "";
                        //txtfood.Text = "";
                        //txtindividuals.Text = "";
                        int b = cs.insert("update camprequest set status='selected' where rid='" + e.CommandArgument + "' ");
                    }
                     else if(food==individuals)
                    {
                        int balance = individuals - food;
                        txtbalance.Text = balance.ToString();
                        //Session["balance"] = balance.ToString();
                        int a = cs.insert("insert into balance(rid,cid,supply,people,balance,needed,status)values('" + e.CommandArgument + "','" + cid + "','" + txtfood.Text + "','" + txtindividuals.Text + "','0',' 0 ','full')");
                        //txtbalance.Text = "";
                        //txtfood.Text = "";
                        //txtindividuals.Text = "";
                        int b = cs.insert("update camprequest set status='selected' where rid='" + e.CommandArgument + "' ");
                    }
                }
                //Session["rid"] = e.CommandArgument;
            }
          
            //int a = cs.insert("update camprequest set status='selected' where rid='" + e.CommandArgument + "'");

        }
    }

    protected void btsearch_Click(object sender, EventArgs e)
    {
        //int rid =Convert.ToInt32( Session["rid"].ToString());
        //int cid = Convert.ToInt32(Session["cid"].ToString());
        //int a=cs.insert("insert into balance(rid,cid,supply,people,balance,needed)values('"+rid+"','"+cid+"','"+txtfood.Text+"','"+txtindividuals.Text+"','"+)
        ScriptManager.RegisterStartupScript(this, GetType(), "Popup", "successalert();", true);
    }
}