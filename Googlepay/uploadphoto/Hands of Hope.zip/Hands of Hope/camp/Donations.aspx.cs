﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Net.Mail;

public partial class camp_Donations : System.Web.UI.Page
{
    Class1 cs = new Class1();
    protected void Page_Load(object sender, EventArgs e)
    {
        if(!IsPostBack)
        {
            GridView1.Visible = false;
            //int cid = Convert.ToInt32(Session["cid"].ToString());
            //DataTable dt = cs.select("select * from donation d join campreg c on d.donid=c.did where c.cid='" + cid + "' ");
            //GridView1.DataSource = dt;
            //GridView1.DataBind();
        }
    }

    protected void GridView1_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandName == "Confirm")
        {
            DataTable dt = cs.select("select * from donation where donid='" + e.CommandArgument + "'");
            if(dt.Rows.Count>0)
            {
                string email = dt.Rows[0]["email"].ToString();

                SmtpClient smtp = new SmtpClient();
                smtp.Host = "smtp.gmail.com";
                smtp.Port = 587;
                smtp.Credentials = new System.Net.NetworkCredential("mysoft.123@gmail.com", "mysoft123");
                smtp.EnableSsl = true;
                MailMessage msg = new MailMessage();
                msg.Subject = "Payment recieved";
                msg.Body = "Hearfull condolences ";
                string toaddress = email;
                msg.To.Add(toaddress);
                string fromaddress = "mysoft.123@gmail.com";
                msg.From = new MailAddress(fromaddress);
                try
                {
                    smtp.Send(msg);
                }
                catch
                {
                    throw;
                }
               


            }
        }
        }
    

    protected void LinkButton1_Click(object sender, EventArgs e)
    {
        GridView1.Visible = true;
    }

   
}
